pdflatex -pdf -pvc trans_img.tex
convert -density 400 trans_img.pdf trans_img.png
